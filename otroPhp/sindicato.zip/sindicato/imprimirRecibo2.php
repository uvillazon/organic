<?php
require_once('lib/includeLibs.php');
require_once('class/imprimirRecibo2.class.php');

$class = new imprimirRecibo;

echo $class->Display();
?>