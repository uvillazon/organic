<?php
	$db_server ='localhost';
	$db_name = 'sindicato_';
	$db_user ='root';
	$db_pass ='';
	?>
