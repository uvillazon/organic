<?php
require_once('lib/includeLibs.php');
require_once('class/insecticidas.php');

$class = new insecticidas;   
echo $class->Display();
?>
