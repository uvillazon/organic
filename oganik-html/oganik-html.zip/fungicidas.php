<?php
require_once('lib/includeLibs.php');
require_once('class/fungicidas.php');

$class = new fungicidas;   
echo $class->Display();
?>
