<?php
require_once('lib/includeLibs.php');
require_once('class/cultivos.php');

$class = new cultivos;   
echo $class->Display();
?>
