<?php
require_once('lib/includeLibs.php');
require_once('class/quienessomos.php');

$class = new quienessomos;   
echo $class->Display();
?>
