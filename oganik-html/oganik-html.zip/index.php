<?php
require_once('lib/includeLibs.php');
require_once('class/index.php');

$class = new index;   
echo $class->Display();
?>
