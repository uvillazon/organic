<?php
require_once('lib/includeLibs.php');
require_once('class/semillas.php');

$class = new semillas;   
echo $class->Display();
?>
