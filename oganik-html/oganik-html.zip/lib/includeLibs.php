<?php
require_once('template.lib.php');

?>