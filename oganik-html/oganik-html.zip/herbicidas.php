<?php
require_once('lib/includeLibs.php');
require_once('class/herbicidas.php');

$class = new herbicidas;   
echo $class->Display();
?>
